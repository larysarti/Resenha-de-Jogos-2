$(document).ready(function(){

$('.a1').click(function(){
			var id;
		id=	$(this).attr('id');
		$('.'+id).toggleClass('escondido');
	})	

$('.a2').click(function(){
			var id;
		id=	$(this).attr('id');
		$('.'+id).toggleClass('escondido');
	})

$('.a3').click(function(){
			var id;
		id=	$(this).attr('id');
		$('.'+id).toggleClass('escondido');
	})


$('.a4').click(function(){
			var id;
		id=	$(this).attr('id');
		$('.'+id).toggleClass('escondido');
	})

$('.a5').click(function(){
			var id;
		id=	$(this).attr('id');
		$('.'+id).toggleClass('escondido');
	})

$('.a6').click(function(){
			var id;
		id=	$(this).attr('id');
		$('.'+id).toggleClass('escondido');
	})




$('.special.cards .image').dimmer({
  on: 'hover'
});
})
